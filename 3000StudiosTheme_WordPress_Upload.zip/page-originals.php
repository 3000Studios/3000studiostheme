
<?php /* Template Name: 3000 Studios Originals */ if ( ! defined('ABSPATH') ) { exit; } get_header(); ?>
<section class="section container">
  <h1>3000 Studios Originals</h1>
  <p>Original films, tracks, and experiences.</p>
</section>
<?php get_footer(); ?>
