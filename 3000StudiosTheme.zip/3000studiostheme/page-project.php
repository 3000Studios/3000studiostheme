
<?php /* Template Name: Project */ if ( ! defined('ABSPATH') ) { exit; } get_header(); ?>
<section class="section container">
  <h1>Projects</h1>
  <p>Showcase your best builds here.</p>
</section>
<?php get_footer(); ?>
