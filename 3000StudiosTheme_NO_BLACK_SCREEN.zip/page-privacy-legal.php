
<?php /* Template Name: Privacy & Legal */ if ( ! defined('ABSPATH') ) { exit; } get_header(); ?>
<section class="section container">
  <h1>Privacy & Legal</h1>
  <div class="scrollbox">
    <p>This site uses cookies and analytics. By using this site you agree to our policies. Update this page with your counsel.</p>
  </div>
</section>
<?php get_footer(); ?>
