/*
 *   Copyright (c) 2025 NAME.
 *   All rights reserved.
 *   Unauthorized copying, modification, distribution, or use of this is prohibited without express written permission.
 */


<?php /* Template Name: 3000 Studios Originals */ if ( ! defined('ABSPATH') ) { exit; } get_header(); ?>
<section class="section container">
  <h1>3000 Studios Originals</h1>
  <p>Original films, tracks, and experiences.</p>
</section>
<?php get_footer(); ?>
